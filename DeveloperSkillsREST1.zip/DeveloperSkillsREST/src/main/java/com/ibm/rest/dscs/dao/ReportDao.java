package com.ibm.rest.dscs.dao;

import java.util.List;

import com.ibm.rest.dscs.domain.Report;

public interface ReportDao {

	public List<Report> getReport();
}