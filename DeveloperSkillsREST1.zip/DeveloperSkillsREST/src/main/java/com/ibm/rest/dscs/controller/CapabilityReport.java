package com.ibm.rest.dscs.controller;

public class CapabilityReport {

}
